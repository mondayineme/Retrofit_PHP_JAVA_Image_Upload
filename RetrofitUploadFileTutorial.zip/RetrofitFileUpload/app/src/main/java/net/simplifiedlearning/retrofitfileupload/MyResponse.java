package net.simplifiedlearning.retrofitfileupload;

/**
 * Created by Belal on 10/5/2017.
 */

public class MyResponse {
    boolean error;
    String message;
}
